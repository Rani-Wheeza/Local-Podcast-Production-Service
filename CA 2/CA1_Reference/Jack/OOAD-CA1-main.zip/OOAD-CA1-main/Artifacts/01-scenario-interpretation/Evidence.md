| Evidence from the scenario | What the evidence tells us |
| :--- | :--- |
|Bookings, participant information, instructor schedules and equipment lists are held in separate systems and paper checklists.| Information is seperated into multiple different systems and manual paper checklists|
|Staff need a consistent view of readiness,changes and confirmed activity status.| Staff dont have a single reliable source of information|
|Conditions (Tides, wind, visibility) may cause a delayed start, route change, relocation, postponement or cancellation which are not described consistently.|Distruptions due to conditions are frequent but how their logged arent consistant|
|Equipment may be physically present but reserved, wet, damaged or awaiting inspection| Equipment physically being there does not mean its available leading to assumptions on ready supply|
|Group organisers may not provide final participant details until shortly before arrival.|A group can be booked before all participant details are shown. What counts as enough detail to confirm is not said.|
|A missing item or late participant detail can affect the whole group.|A missing item or late participant can have group-wide effects, so thing have to be checked before the session.