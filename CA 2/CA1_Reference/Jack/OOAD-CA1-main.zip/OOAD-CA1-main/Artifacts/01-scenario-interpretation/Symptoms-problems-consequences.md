|Observation or symptom | Underlying problem | Likely consequence|
| :--- | :--- | :--- |
|Equipment can be physically in the store but not usable for activitys eg.(reserved, wet, damaged or awaiting inspection)|Staff have no single main record of whether equipment is actually ready since the equipment lists are in seperate systems and paper checklists|A Session may be planned or ready to go with equipment that isnt ready and a missing item will effect the whole group|
|Delayed starts, route changes, relocations, postponements and cancellations are described inconsistently|No aggreed way to describe outcomes|Staff might have different ways of describing outcomes leading to data inconsistances|
|A booking may not be ready just because spaces remain.|There could be Overbooking for sessions that arent ready| A session thats not ready may have group-wide effects like a missing item or late participant|
|Group organisers may not provide final details of participants until shortly before arrival| if the details arrive late staff might not be ready/prepared for the session| if the details are still missing before the session it may be cancelled

