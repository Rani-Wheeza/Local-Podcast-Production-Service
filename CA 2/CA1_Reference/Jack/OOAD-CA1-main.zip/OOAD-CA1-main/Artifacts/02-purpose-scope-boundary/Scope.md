| In scope for the initial release | Out of scope for the initial release |
|---|---|
| Activity and session records, including time, location or route, capacity and requirements | Payment processing and refunds|
| Bookings and participant records for individuals, families and groups | Live monitoring or forecasting of weather and sea conditions |
| Recording staff checks of participant requirements for an activity | Automated safety, suitability, route or cancellation decisions |
| Instructor qualifications, approvals and session assignments | Emergency-service dispatch |
| Equipment records, including condition, inspection status and readiness | Managing transport operations |
| Staff checks of session readiness, including participants, instructors, equipment, access and conditions | Detailed medical records |
| Recording attendance, equipment issued, routes used and session outcomes |  |
| Recording delays, route changes, relocations, postponements and cancellations |  |
| Recording damage, loss and incidents for follow-up |  |
| Basic operational views and reports on sessions, readiness, shortages and unresolved incidents |  |