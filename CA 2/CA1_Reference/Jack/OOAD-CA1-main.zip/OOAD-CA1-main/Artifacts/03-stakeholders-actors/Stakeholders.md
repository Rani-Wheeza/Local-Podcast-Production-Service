
| Stakeholder | Goals | Concerns | Influence | Expected interaction |
|---|---|---|---|---|
| Operations manager | Monitors session readiness and Equipment Records & Incidents are resolved | Session and Equipment Records are reliable & unresolved incidents/decisions are visible | High  | View Session, Equipment and incident/decision Records |
| Instructor | Runs Sessions using the right route equipment and participant information | Unsuitible conditions, missing participant details or unavailable equipment items  | Medium | View Session, Equipment,Conditions and particapant Records |
| Participant | Book and participate in their session and stay informed of changes | Session Details changing, equipment not ready for use | Medium | Find an Book Sessions and view session details |
| Equipment coordinator | Keeping equipment records accurate and ensuring session equipment is ready | Equipment Records being inacurate, equipment being missing or not ready for use | High | View Session and Equipment Records |
| Group organiser | Organising group bookings and ensuring required details are ready before planned sessions | Session Details may change before session start | High | Access Session and Participant Details |
| Safety lead | Ensure activities are run in safe and suitable conditions, keeping records of any incidents | A session going ahead in improper conditions and incidents not being recorded accurately | High | View and Access Conditions and incident records |
| 