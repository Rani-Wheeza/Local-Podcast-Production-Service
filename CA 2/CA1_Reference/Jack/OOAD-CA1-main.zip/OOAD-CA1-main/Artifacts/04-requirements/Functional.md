| ID | Functional requirement | Priority | Source |
|---|---|---|---|
| FR-01 | The System shall allow a user to book a session | Must | Participant |
| FR-02 | The System shall allow Staff to Record and view any incidents that accur | Must | Safety Lead |
| FR-03 | The System shall allow Staff to Record a sessions status, route change,relocation or cancllation | Must | Instructor |
| FR-04 | The System shall allow Staff to record/view a sessions equipment used, route used and sessions outcome | Must | Instructor |
| FR-05 | The System shall allow Staff to Record/view equipment readyness and condition(wet,damaged or awaiting inspection) | Must | Equipment Coordinator|
| FR-06 | The System shall allow a user to record/view paricipant details for a selected session | Must | Group Organiser |
| FR-07 | The System shall allow a user to create a session | Must | Operations Manager |
| FR-08 | The System shall allow Staff to check for session readyness | Must | Operations manager |
| FR-09 | The System shall allow a user to cancel a sessions booking | Should | Participant |
| FR-10 | The System shall allow Staff to change session state from booked to ready | Must | Operations Manager |
| FR-11 | The System shall allow Staff to record instructor assignments and qualifications | Should | Instructor |
| FR-12 | The System shall allow staff to Record/View basic reports on session outcomes | Could | Safety Lead |