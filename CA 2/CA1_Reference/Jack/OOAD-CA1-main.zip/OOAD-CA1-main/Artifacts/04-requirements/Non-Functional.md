| Weak statement | Improved requirement | Quality |
|---|---|---|
|The System should be fast| NFR-01 System readiness, route changes or cancellations Records shall be displayed/Updated within 5 seconds for atleast 90% of requests to display and a maximum of 1 minute to update/Refresh records | Performance |
|The system should always be available| NFR-02 The System shall be available during opening hours excluding Staff where the system shall be available 24 hours| Availablility |
|The System must protect participant information| NFR-03 A participant may only view the session/participant details assosiated with their own sessions | Privacy |
|The System should be secure| NRF-04 System Funtions should only be available to the staff/participant with the corisponding role| Security |