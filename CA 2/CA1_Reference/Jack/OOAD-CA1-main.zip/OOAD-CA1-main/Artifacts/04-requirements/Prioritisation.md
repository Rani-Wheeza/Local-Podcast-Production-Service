| Priority | Meaning | Worked interpretation |
|---|---|---|
| Must | Essential to achieve the release purpose | Prevent sessions being double or overbooked |
| Should | Important, but a temporary work-around exists | Allow Session Cancellation Online |
| Could | Desirable if time and resources permit | Ambulance incident recovery Records |
| Won't this time | Explicitly deferred from the current release | Moblile App |
