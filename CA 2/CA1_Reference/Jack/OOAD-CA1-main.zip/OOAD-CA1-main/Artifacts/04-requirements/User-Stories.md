# User Stories
US-01
As an operations manager, I want to confirm whether a session is ready before approving it, so that I can reduce overbooking.

| Story part | Worked content | Reason |
|---|---|---|
| Role | Operations manager | The role is specific and reflects the stakeholder |
| Goal | Confirm whether a session is ready before approval | The Goal is clear and meaningful |
| Benefit | Reduce overbooking | The benifit explains the value of the goal |

US-02
As a participant, I want to have access to when my session’s start time, location, route, or status changes, so that I know where and when to attend.

| Story part | Worked content | Reason |
|---|---|---|
| Role | Participant | The role is specific and reflects the stakeholder |
| Goal | Have access to Records when the session's start time location,route or status changes | The Goal is clear and shows the information the participant needs |
| Benefit | Know where and when to attend | The benifit explains how fast updates help the participant |

US-03
As an equipment coordinator, I want to see whether equipment is inspected, available, and suitable for a session, so that staff do not assign equipment that is reserved, damaged, wet, or awaiting inspection.

| Story part | Worked content | Reason |
|---|---|---|
| Role | Equipment Coordinator | The role is specific and reflects the stakeholder |
| Goal | See whether equipment is inspected, available, and suitable for a session | The goal is clear and supports equipment readiness checks|
| Benefit | Prevent staff from assigning equipment that has bad conditions, or awaiting inspection | The benefit explains how this helps avoid unsuitable equipment being assigned |

US-04
As a group organiser, I want to provide the confirmed group size before submitting every participant’s details, so that staff can plan capacity while I gather the remaining information.

| Story part | Worked content | Reason |
|---|---|---|
| Role | Group Organiser | The role is specific and reflects the stakeholder |
| Goal | Provide the confirmed group size before submitting every participant’s details | The goal looks at the scenario where participant details may arrive late|
| Benefit | Let staff plan capacity while the remaining information is gathered | The benefit explains why confirming the group size early is useful |

US-05
As a safety lead, I want to review incidents and their follow-up actions per session and equipment, so that I can track unresolved matters without assuming their cause.

| Story part | Worked content | Reason |
|---|---|---|
| Role | Safety lead | The role is specific and reflects the stakeholder |
| Goal | Review incidents and follow-up actions per session and equipment | The goal describes the information needed to review and follow up on incidents |
| Benefit | Track unresolved matters without assuming their cause | The benefit explains how this supports careful, evidence-based follow-up |

US-06
As an instructor, I want to review the session’s participant numbers, equipment readiness, and current conditions before it starts, so that I can prepare to deliver the activity safely.

| Story part | Worked content | Reason |
|---|---|---|
| Role | Instructor | The role is specific and reflects the stakeholder |
| Goal | Review participant numbers, equipment readiness, and current conditions before the session starts | The goal identifies the key information the instructor needs to prepare |
| Benefit | Prepare to deliver the activity safely | The benefit explains how the review supports safe session delivery |
