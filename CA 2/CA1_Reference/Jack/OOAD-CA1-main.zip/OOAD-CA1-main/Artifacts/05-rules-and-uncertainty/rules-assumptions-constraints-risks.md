| Type | Worked example | Explanation |
|---|---|---|
|Constraint| The system does not procces payments| marked as out of scope|
Rule| A booking cannot be set as ready until Session,Participant and equipment are ready/have been checked| reflects need for session to be ready not space available|
|Assumption| Intructors have approved qualifications for the activities,sessions they are assigned to| Believed true but must be verified
|Constraint|the system does not include live weather monitering or emergency service dispatch|marked as out of scope|
|Risk| A session may end up overbooked of spaces are treated as readyness | shows risk that bookings may be accepted even when the session isnt ready to run|
|Assumption| Equipment condition and inspection status will be checked by staff in the system| Assumes true but must be verified |