## 4.2.1. [Check Session Readiness]

| Field | Worked content |
|---|---|
| Use Case Name | Check Session Readiness |
| Use Case ID | 3 |
| Priority | Must |
| Source | FR-08 — Operations Manager |
| Primary Business Actor | Operations Manager |
| Other Participating Actors | Instructor, Equipment Coordinator |
| Description | Allows the operations manager to view checks and information for a session. Record the readyness descision and make the sessions readyness visible. |
| Preconditions | The Sessions exists and he operations manager can access its records|
| Trigger | The operations manager needs to confirm the session’s readiness before approving it. |

### Expected Scenario

| Expected Scenario | Actor Name | System |
|---|---|---|
| | **Step 1:** Selects the session to check.<br><br>**Step 3:** Reviews the displayed information and records the readiness decision and any notes. | **Step 2:** Displays the session details, participant checks, instructor assignment and qualifications, equipment readiness, and other recorded readiness checks.<br><br>**Step 4:** Saves the readiness check and displays the updated session status. |


### Alternate Scenarios

| Scenario | Actor | System |
|---|---|---|
| **Session Not Ready** | **Step 3:** Records the session as not ready and adds notes. | **Step 4:** Saves the readiness check and keeps the session status as Not Ready. |
| **Session Ready** | **Step 3:** Records the session as ready. | **Step 4:** Saves the readiness check and updates the session status to Ready. |
| **Save Failed** | **Step 6:** Retries saving or reports the problem to the appropriate staff member. | **Step 4:** Saving the readiness check fails.<br><br>**Step 5:** Notifies the actor that the check was not saved; the session status remains unchanged. |
