# Use-case Catalogue

| Use case | Primary actor | Meaningful outcome |
|---|---|---|
| Book or Cancel Session | Participant | A booking is recorded or cancelled. |
| Manage Session | Operations manager | A session and its instructor assignment are recorded or updated. |
| Check Session Readiness | Operations manager | Readiness checks are recorded and the session’s readiness is visible. |
| Maintain Equipment Readiness | Equipment coordinator | Equipment condition and inspection status are recorded. |
| Record Session Outcome | Instructor | Attendance, equipment issued, route used, and session outcome are recorded. |
| Record Incident and Follow-up | Safety lead | An incident and its follow-up actions are recorded against the relevant session and equipment. |


![Use case diagram](../../Diagrams/Use-Case-Diagram.png)