# Evidence excerpt

> “Bookings, participant information, instructor schedules and equipment lists are held in separate systems and paper checklists.”
>
> “Staff need a consistent view of readiness, changes and confirmed activity status.”

## Initial extraction

| Candidate term | Possible interpretation |
|---|---|
| session | Scheduled activity with a time, status, and readiness |
| booking | A participant's or group's place on a session |
| participant | Person attending a session |
| instructor | Staff member assigned to lead a session |
| equipment | Item tracked for condition and availability |
| readiness check | Recorded review of whether a session is ready to proceed |