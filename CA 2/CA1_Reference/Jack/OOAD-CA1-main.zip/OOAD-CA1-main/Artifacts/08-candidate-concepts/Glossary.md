# Worked Glossary

| Concept | Definition | Related concepts |
|---|---|---|
| Session | A scheduled outdoor activity with a time, capacity, location or route, and status. | Booking, Instructor, Equipment Item, Readiness Check |
| Booking | A record of a participant's or group's place on a session. | Session, Participant |
| Participant | A person who attends a session and whose details and checks may be recorded. | Booking, Session |
| Instructor | A staff member assigned to lead a session, with qualifications recorded | Session, Readiness Check |
| Equipment Item | An individual piece of equipment tracked for condition, inspection, availability, and session use. | Session, Readiness Check |
| Readiness Check | A staff recorded review of the information needed to decide whether a session is ready to proceed. | Session, Participant, Instructor, Equipment Item |