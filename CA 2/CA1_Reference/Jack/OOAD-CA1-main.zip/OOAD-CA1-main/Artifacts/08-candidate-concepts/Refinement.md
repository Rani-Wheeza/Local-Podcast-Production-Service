# Refined Decisions

| Candidate | Classification | Decision | Reason |
|---|---|---|---|
| Session | Conceptual class | Keep | Has its own time, capacity, status, and readiness, and connects bookings, participants, instructors, and equipment. |
| Booking | Conceptual class | Keep | A participant's or group's place on a session and can be created or cancelled. |
| Participant | Conceptual class | Keep | Participant details and checks must be recorded and linked to a session or booking. |
| Instructor | Conceptual class | Keep | Instructors have recorded qualifications and are assigned to sessions. |
| Equipment | Conceptual class | Refine to Equipment Item | Each item needs its own condition, inspection status, and availability record. |
| Readiness check | Conceptual class | Keep | Staff record readiness information and a decision for a session; this is more than a single session status. |