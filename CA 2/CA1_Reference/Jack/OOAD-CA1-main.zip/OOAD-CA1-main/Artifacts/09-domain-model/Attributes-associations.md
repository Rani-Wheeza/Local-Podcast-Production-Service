# Select Essential Attributes

| Concept | Candidate attributes | Keep / remove | Reason |
|---|---|---|---|
| Activity | name, usual duration, usual capacity, equipment requirements, instructor requirements | Keep name usal duration, and usual capacity. Show equipment and instructor requirements with relationships. | Seperates activity types and captures their planning needs without storing related concepts as text. |
| Session | start time, location, route, capacity, status | Keep start time, location, route, capacity, and status. | These Show a scheduled occurrence and support booking and readiness decisions. |
| Booking | booking date, status, group size, participant details | Keep booking date, status, and group size when applicable. Represent participants through a relationship. | A booking has its own lifecycle and may represent an individual or a group whose final participant details arrive later. |
| Participant | name, age, experience, swimming confidence, contact details, detailed medical history | Keep name and practical suitability information needed for the activity. Remove detailed medical history. | The brief calls for practical suitability checks, not a clinical assessment or detailed medical record. |
| Instructor | name, qualifications, approved activities, availability | Keep name. Show qualifications and approved activities through relationships And Show availability through session assignments. | Instructors may have multiple qualifications and approvals, and their availability depends on their assignments. |
| Equipment Item | equipment type, size, condition, inspection status, availability | Keep equipment type, size, condition, and inspection status. Treat availability as a result of condition, inspection, and reservations or assignments. | The brief distinguishes physical presence from being inspected, suitable, and available for a session. |
| Readiness Check | date, decision, notes, participant checks, instructor checks, equipment checks, access, conditions | Keep date, decision, and notes. Show the reviewed participant, instructor, equipment, access, and condition information through relationships or recorded check details. | The check records a staff review and decision. |
| Session Outcome | attendance, equipment issued, route used, outcome, early departure | Keep attendance, equipment issued, route used, and outcome. | These are explicitly recorded when a session is completed; an early departure can be captured in attendance or outcome details. |
| Incident | description, date and time, status, cause, follow-up | Keep description, date and time, status, and follow-up actions. Do not assume or store a cause unless it is established and recorded as evidence. | Incidents need follow-up and links to relevant sessions or equipment, while the brief warns against assuming a single cause. |

# Identify and name associations

| Class A | Association name or sentence | Class B | Evidence | Keep? |
|---|---|---|---|---|
| Activity | is delivered as | Session | An activity type has many scheduled sessions with a time, location, route, and capacity. | Yes |
| Instructor | leads | Session | Instructors are assigned to sessions and their availability is tied to session assignments. | Yes |
| Participant | books / attends | Session | A booking records a participant’s involvement in a session and session capacity matters. | Yes |
| Booking | is made by | Participant | Booking details are linked to the person taking part in the activity. | Yes |
| Booking | is for | Session | A booking is created for a specific session and its status and group size are tracked. | Yes |
| Session | uses | Equipment Item | Sessions depend on equipment being suitable, available, and checked before use. | Yes |
| Readiness Check | validates readiness for | Session | A readiness check reviews the participant, instructor, equipment, and conditions before the session runs. | Yes |
| Incident | occurs during | Session | Incidents are recorded with time, status, and follow-up and are linked to relevant sessions. | Yes |

# Assign and justify multiplicities

| Association | Class A | Class B | Multiplicity at A | Multiplicity at B | Reading from both ends | Evidence / rule |
|---|---|---|---|---|---|---|
| Activity – Session | Activity | Session | 1 | 0..* | An Activity can have many Sessions. Each Session is for one Activity. | A session is a scheduled occurrence of an activity, so many sessions can belong to one activity. |
| Instructor – Session | Instructor | Session | 0..* | 1..* | An Instructor may lead many Sessions, and a Session may have one or more Instructors. | Staff are assigned to sessions based on availability and role requirements. |
| Participant – Booking | Participant | Booking | 0..* | 1 | A Participant can make many Bookings. Each Booking belongs to one Participant. | Booking records the participant’s involvement in a session. |
| Booking – Session | Booking | Session | 1 | 1 | Each Booking is for one Session, and each Session can have many Bookings. | A booking is created for a specific session and is linked to its capacity and status. |
| Session – Equipment Item | Session | Equipment Item | 0..* | 0..* | A Session may use many Equipment Items, and an Equipment Item may be used across many Sessions. | Equipment suitability and availability are part of session planning and readiness checks. |
| Session – Readiness Check | Session | Readiness Check | 1 | 0..1 | A Session is assessed by a Readiness Check, and a Readiness Check is for one Session. | The check records the decision before the session runs. |
| Session – Incident | Session | Incident | 1 | 0..* | A Session may have many Incidents, and each Incident relates to one Session. | Incidents are recorded during or in connection with a session. |

Multiplicity reference:
- 1 = exactly one
- 0..1 = zero or one
- 0..* = zero or many
- 1..* = one or many


   ![Domain model](../../Diagrams/DomainModel.png)