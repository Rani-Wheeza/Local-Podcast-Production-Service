# Validate transactions and historical records

| Information to retain | Best owning concept | Why |
|---|---|---|
| Booking and participant details for a session | Booking / Participant | The scenario identifies bookings and participant information as records that need to be brought together; group details may be completed later. |
| Session status and changes, including delays, route changes, relocations, postponements, and cancellations | Session | These changes need to be recorded consistently so staff can see the confirmed session status. |
| Readiness check date, decision, and notes | Readiness Check | Staff need to record whether participants, instructors, equipment, access, and conditions have been checked before a session proceeds. |
| Equipment condition and inspection status | Equipment Item | Equipment can be present but reserved, wet, damaged, or awaiting inspection, so its condition and readiness must be recorded. |
| Attendance, equipment issued, route used, and session outcome | Session Outcome | These are the main things recorded when a session is completed and support basic operational reporting. |
| Incident details, date/time, status, and follow-up | Incident | Damage, loss, and other incidents need a record so staff can track follow-up. |
