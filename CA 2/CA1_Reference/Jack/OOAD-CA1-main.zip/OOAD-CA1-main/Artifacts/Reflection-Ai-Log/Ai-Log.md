I used Claud ai and Vscodes Build in Copilot at level 3. I used them for Making my Folder Structure so i knew what files to make and what lab session went to each file. I also used them for templates, to see if my drafts were good and a small few example which i changed to fit my Scenario.
I did not use AI to generate my interpretation, requirements, stakeholder analysis, concept decisions, domain model or reflection.

## AI use example: Folder and file structure

| Field | Entry |
|---|---|
| Date and tool | 16 Oct 2026, Claude |
| Purpose | Folder and file structure for the CA repository |
| My input | The brief's artefact list and the Session 3 to 7 labs, plus my request to organise by the brief's artefacts and not by session |
| AI suggestion | An artefact-named folder layout, mapped to lab steps |
| My evaluation | I noticed the structure it gave me was a bit bloated so i removed some of the files it made and renamed some of them to fit my repo |
| My decision | Used the artefact-named layout with my own edits. All content inside the files is my own |
| Evidence link | Repository structure, first commit |

## AI use example: Converting Lab Tables to Markdown

| Field | Entry |
|---|---|
| Date and tool |21 - 23 Oct 2026, GitHub Copilot (VS Code) |
| Purpose | Take the lab worked table examples and convert them into markdown so i could focus on the content |
| My input | The lab templates and layouts, pasted or described |
| AI suggestion | Markdown table skeletons with the lab’s column headings |
| My evaluation | The output was formatting only. I checked the headings against the lab, and I wrote all the content in the cells myself |
| My decision | Used the Skeleton Tables as a starting point for evidence, symptoms table, stakeholders, requirements, prioritisation, user stories where i filled in my own content |
| Evidence link | Completed files: [Evidence](../01-scenario-interpretation/Evidence.md), [Symptoms](../01-scenario-interpretation/Symptoms-problems-consequences.md), [Stakeholders](../03-stakeholders-actors/Stakeholders.md), [Functional requirements](../04-requirements/Functional.md), [Non-functional requirements](../04-requirements/Non-Functional.md), [Prioritisation](../04-requirements/Prioritisation.md), and [User stories](../04-requirements/User-Stories.md) |
