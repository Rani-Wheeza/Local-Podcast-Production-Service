# CA1 Scenario 11: Wild Atlantic Way Activity Booking Service

Scenario ID: CA1-11-WAWABS | Organisation: Atlantic Edge Experiences

> Use scenario evidence, state temporary assumptions clearly, and identify questions or risks where stakeholder confirmation is required. Where evidence is incomplete or inconsistent, identify the uncertainty rather than inventing a confirmed policy.

## Organisation and current service

Atlantic Edge Experiences provides guided kayaking, coastal walking and introductory outdoor sessions along the Wild Atlantic Way. Activities use instructors, locations and specialist equipment whose suitability depends on participant needs and current conditions.

Bookings, participant information, instructor schedules and equipment lists are held in separate systems and paper checklists. Staff need a consistent view of readiness, changes and confirmed activity status.

## Activities, sessions and conditions

Each activity type has usual duration, capacity, location, equipment and instructor requirements. A scheduled session may use a particular route or water area, but an approved alternative can be selected if conditions change.

Tides, wind, visibility, access restrictions and transport arrangements affect the session. Conditions may cause a delayed start, route change, relocation, postponement or cancellation. These outcomes are not always described consistently.

Private groups may request tailored start times or content. A request remains provisional until instructor, equipment, location and participant requirements have been reviewed.

## Bookings and participant requirements

A booking may contain one participant, a family or an organised group. Staff collect practical information needed to assess activity and equipment suitability. Group organisers may not provide final participant details until shortly before arrival.

Some activities have age, experience, supervision or swimming-confidence expectations. Staff want evidence of a completed suitability review without turning the booking process into a clinical assessment.

Participants may transfer, withdraw or request a different activity. A replacement participant may require a new suitability and equipment review.

## Instructors and equipment readiness

Instructors hold different qualifications and are approved for particular activities, locations and group types. Some sessions require two instructors or additional shore support.

Equipment includes buoyancy aids, helmets, paddles, wetsuits, dry bags and communication devices. Size, condition, inspection status and complete sets matter. Equipment may be physically present but reserved, wet, damaged or awaiting inspection.

Before the session, staff confirm instructors, participant numbers, suitable equipment, transport, access and conditions. A missing item or late participant detail can affect the whole group.

## Completion, incidents and information

Attendance, equipment issued, route used and session outcome are recorded. A participant may leave early, change equipment or not enter the activity after arrival.

Damage, loss and incidents require follow-up. Staff should connect records to the session, participant where appropriate and equipment item without assuming a single cause.

The operations manager needs information about provisional and confirmed sessions, equipment shortages, instructor coverage, condition decisions and unresolved incidents. Payment processing, emergency-service dispatch and live environmental monitoring are outside scope.

## Stakeholder evidence

- Operations manager: "A booking is not ready just because spaces remain."
- Instructor: "The planned route may be unsuitable while an approved alternative is safe to use."
- Participant: "I need to know whether the activity moved, changed or was cancelled."
- Equipment coordinator: "Present in the store does not mean inspected and ready."
- Group organiser: "Our number may be confirmed before every participant detail is available."
- Safety lead: "An incident record should preserve evidence rather than jump to a conclusion."

## Unresolved matters

The scenario does not confirm every policy or decision. Clarification may be required about:

- which participant information is required before confirmation;
- who may approve suitability, route changes or cancellation;
- when a private-group request reserves capacity;
- how replacement participants should be handled;
- when equipment becomes reserved and what makes a complete ready set;
- how damage, loss and incidents should be linked without assuming cause;
- which participant and operational information instructors and partners may see.